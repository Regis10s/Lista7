import java.util.Scanner;
import ValidacaoCpf;

public class Exercicio3Lista7 {
    public static void main(String[] args) {
    Scanner scanner = new Scanner (System.in);

ValidacaoCpf cpf = new ValidacaoCpf();

    System.out.println("Indique o Cpf, no formato xxx.xxx.xxx-xx: ");
    cpf.setCPF(scanner.nextLine());





scanner.close();


    }
    
}
